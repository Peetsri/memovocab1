from django.shortcuts import render , redirect
from django.views.generic import ListView
from .models import memovocab_test1
from django.http import HttpResponse

# Create your views here.
class HomePageView(ListView):
    model = memovocab_test1
    template_name = 'home.html'

def cal1PageView(request):
    return render(request, 'cal_1.html')

def signupPageView(request):
    return render(request, 'signup.html')

def loginPageView(request):
    return render(request, 'login.html')

def profilePageView(request):
    return render(request, 'profile.html')

