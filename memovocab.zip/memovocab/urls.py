from django.urls import path
from .views import HomePageView,signupPageView,loginPageView,cal1PageView,profilePageView

urlpatterns = [
    path('', HomePageView.as_view(), name='home'),
    path('cal_1/', cal1PageView, name='cal_1'),
    #path('about/', aboutPageView, name='about'),
    path('signup/', signupPageView, name='signup'),
    path('login/', loginPageView, name='login'),
    path('profile/', profilePageView, name='profile'),
  

]