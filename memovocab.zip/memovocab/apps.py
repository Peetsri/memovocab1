from django.apps import AppConfig


class MemovocabConfig(AppConfig):
    name = 'memovocab'
